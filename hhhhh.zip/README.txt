ADNAN.PY — FLAPPY FLIGHT
========================

Run:
- Extract this ZIP.
- Open index.html in a modern browser, or host the folder on GitHub Pages.
- For GitHub Pages, upload the contents of this folder to the repository root and enable Pages in Settings.

Controls:
- Tap/click anywhere to flap.
- Space, Arrow Up, or Enter also flaps.
- Tap the sound icon in the top-right to toggle sound.
- After game over, tap to restart.

Included:
- Reuses the images, sounds, and four theme folders from the uploaded ZIP.
- Portrait responsive HTML5 Canvas game.
- Tap impulse + gravity, animated bird frames, scrolling background/ground,
  randomized pipe gaps, collision, scoring, best score, game-over and restart.
- "CREATED ADNAN.PY" intro.

Important:
- This is a new browser implementation inspired by the classic one-button pipe-dodging mechanic, not the original source code.
- The supplied ZIP contains many original app/package files that are not needed for this web project; only assets were carried over.
- This is not an APK. Host it as a web game or wrap it with Android WebView to build an APK.
- Verify licensing/permission before publicly redistributing supplied game artwork or audio.
